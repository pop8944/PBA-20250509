﻿using System;
using System.Diagnostics;
using System.Windows.Forms;
using System.Reflection;
using System.Drawing;

using Cognex.VisionPro;
using Cognex.VisionPro.PMAlign;
using Cognex.VisionPro.Exceptions;
using Cognex.VisionPro.Caliper;
using Cognex.VisionPro.ToolGroup;


namespace IntelligentFactory
{
    public class CCogTool_FindLine
    {
        public string NAME { get; set; } = "";
        private CogFindLineTool m_cogTool = new CogFindLineTool();
        public CogFindLineTool Tool
        {
            get => m_cogTool;
            set => m_cogTool = value;
        }

        private CogFindLineResults m_cogResult = new CogFindLineResults();
        public CogFindLineResults Result
        {
            get => m_cogResult;
            set => m_cogResult = value;
        }
        
        private CogLine m_ResultLine = new CogLine();
        public CogLine ResultLine
        {
            get => m_ResultLine;
        }
        private string m_strPath = string.Empty;
        private PointF m_ptStart = new PointF();
        private PointF m_ptEnd = new PointF();

        public CCogTool_FindLine(string strName)
        {
            NAME = strName;
        }
        public bool LoadConfig(string strRecipe)
        {
            try
            {
                string strPath = $"{Application.StartupPath}\\RECIPE\\{strRecipe}\\{NAME}.vpp";
                if (LoadConfig_Manual(strPath) == true)
                    return true;
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
            return false;
        }

        public bool LoadConfig_Manual(string strPath)
        {
            try
            {
                if (CogSerializer.LoadObjectFromFile(strPath) is CogFindLineTool)
                {
                    m_strPath = strPath;
                    m_cogTool = CogSerializer.LoadObjectFromFile(strPath) as CogFindLineTool;

                    return true;
                }
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
            return false;
        }
        public void SaveConfig(string strRecipe)
        {
            try
            {
                string strPath = $"{Application.StartupPath}\\RECIPE\\{strRecipe}\\{NAME}.vpp";
                CogSerializer.SaveObjectToFile(m_cogTool, strPath);
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
        }

        public void SetInfo(CogFindLineTool Info)
        {
            m_cogTool = Info;
        }
        /* LINE 검색 영역 설정
         * cogROI : Line 검색 할 영역
         * enSearchDir : 검색 방향
         */
        public void SetInfo(CogRectangleAffine cogROI, ENDIRECTION enSearchDir)
        {
            // ROI 영역 변경
            switch (enSearchDir)
            {
            case ENDIRECTION.X:
                {
                    m_cogTool.RunParams.ExpectedLineSegment.StartX = cogROI.CornerOriginX;
                    m_cogTool.RunParams.ExpectedLineSegment.StartY = cogROI.CornerOriginY + (cogROI.SideYLength / 2);
                    m_cogTool.RunParams.ExpectedLineSegment.EndX = cogROI.CornerOriginX + cogROI.SideXLength;
                    m_cogTool.RunParams.ExpectedLineSegment.EndY = cogROI.CornerOriginY + (cogROI.SideYLength / 2);
                }
                break;
            case ENDIRECTION.Y:
                {
                    m_cogTool.RunParams.ExpectedLineSegment.StartX = cogROI.CornerOriginX + (cogROI.SideXLength / 2);
                    m_cogTool.RunParams.ExpectedLineSegment.StartY = cogROI.CornerOriginY;
                    m_cogTool.RunParams.ExpectedLineSegment.EndX = cogROI.CornerOriginX + (cogROI.SideXLength / 2);
                    m_cogTool.RunParams.ExpectedLineSegment.EndY = cogROI.CornerOriginY + cogROI.SideYLength;
                }
                break;
            default:
                break;
            }
        }
        /* LINE 찾기 결과
         * outLine : 찾은 선의 정보
         * outResults : 선을 찾는데 사용한 Caliper의 정보
         * return : 정공율
         */
        public float GetResult(out CogLine outLine, out CogFindLineResults outResults)
        {
            outLine = m_ResultLine;
            outResults = m_cogResult;

            if (m_ResultLine == null || m_cogResult == null || m_cogTool.Results == null)
                return 0;

            int nFound = m_cogTool.Results.NumPointsFound; // 찾은 점의 개수
            int nNumCalipers = m_cogTool.RunParams.NumCalipers; // 찾을 점의 개수
            if (nNumCalipers == 0)
                return 0;
            return (float)(nFound / nNumCalipers);
        }
        /* 선의 시작점, 끝점 만 반환
         */
        public void GetResultLine(out PointF ptLineStart, out PointF ptLineEnd)
        {
            ptLineStart = m_ptStart;
            ptLineEnd = m_ptEnd;
        }
        /* LINE 찾기 - .vpp에서 RunParam 변경없이 검색
         * Image : 이미지
         * fScore : 성공율
         */
        public bool Run(CogImage8Grey Image, float fScore)
        {
            try
            {
                m_cogTool.InputImage = Image;
                // 설정값 입력은 없다.
                // .vpp에서 읽은 정보를 그대로 사용
                m_cogTool.Run();

                if (null != m_cogTool.Results && m_cogTool.Results.Count > 0)
                {
                    if (m_cogTool.Results.GetLine() != null)
                    {
                        m_ResultLine = m_cogTool.Results.GetLine();

                        // Line 정보 읽기
                        double dblX0 = 0.0, dblY0 = 0.0, dblRotate = 0.0;
                        m_ResultLine.GetXYRotation(out dblX0, out dblY0, out dblRotate);
                        double dblAngle = Common.rad2deg(dblRotate);

                        // 위에서 찾은 Line에서 임의의 X좌표에 대한 Y좌표 찾기
                        double dblX1 = dblX0 + 1;
                        double dblY1 = (Math.Tan(dblRotate) * (dblX1 - dblX0)) + dblY0;

                        m_ptStart.X = (float)dblX0;
                        m_ptStart.Y = (float)dblY0;
                        m_ptEnd.X = (float)dblX1;
                        m_ptEnd.Y = (float)dblY1;
                    }
                }
                if (m_cogTool.Results == null)
                    return false;

                m_cogResult = m_cogTool.Results;
                int nFound = m_cogTool.Results.NumPointsFound;
                int nNumCalipers = m_cogTool.RunParams.NumCalipers;
                float fRet = (float)nFound / (float)nNumCalipers;
                if (fRet < fScore) // 설정한 정확도 보다 낮으면 실패
                    return false;
                return true;
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.ABNORMAL, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
            return false;
        }
        /* LINE 찾기 - .vpp에서 RunParam 변경없이 검색
         * Image : 이미지
         * fScore : 성공율
         * pt0, pt1 : 선의 시작점과 끝점
         */
        public bool FindLineProcess(CogImage8Grey Image, float fScore, out PointF ptLineStart, out PointF ptLineEnd)
        {
            ptLineStart = new PointF();
            ptLineEnd = new PointF();
            try
            {
                m_cogTool.InputImage = Image;
                // 설정값 입력은 없다.
                // .vpp에서 읽은 정보를 그대로 사용
                m_cogTool.Run();

                if (null != m_cogTool.Results && m_cogTool.Results.Count > 0)
                {
                    if (m_cogTool.Results.GetLine() != null)
                    {
                        m_ResultLine = m_cogTool.Results.GetLine();

                        // Line 정보 읽기
                        double dblX0 = 0.0, dblY0 = 0.0, dblRotate = 0.0;
                        m_ResultLine.GetXYRotation(out dblX0, out dblY0, out dblRotate);
                        double dblAngle = Common.rad2deg(dblRotate);

                        // 위에서 찾은 Line에서 임의의 X좌표에 대한 Y좌표 찾기
                        double dblX1 = dblX0 + 1;
                        double dblY1 = (Math.Tan(dblRotate) * (dblX1 - dblX0)) + dblY0;

                        // 결과 저장
                        ptLineStart.X = (float)dblX0;
                        ptLineStart.Y = (float)dblY0;
                        ptLineEnd.X = (float)dblX1;
                        ptLineEnd.Y = (float)dblY1;

                        m_ptStart.X = (float)dblX0;
                        m_ptStart.Y = (float)dblY0;
                        m_ptEnd.X = (float)dblX1;
                        m_ptEnd.Y = (float)dblY1;
                    }
                }
                if (m_cogTool.Results == null)
                    return false;

                m_cogResult = m_cogTool.Results;
                int nFound = m_cogTool.Results.NumPointsFound;
                int nNumCalipers = m_cogTool.RunParams.NumCalipers;
                if ((float)(nFound / nNumCalipers) < fScore) // 설정한 정확도 보다 낮으면 실패
                    return false;
                return true;
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.ABNORMAL, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
            return false;
        }
        /* LINE 찾기 - .vpp에서 ROI 영역만 변경하여 검색
         * Image : 이미지
         * fScore : 성공율
         * cogROI : Line을 찾을 영역
         * enSearchDir : Line찾을 방향, X방향, Y방향
         * pt0, pt1 : 선의 시작점과 끝점
         */
        public bool FindLineProcess(CogImage8Grey Image, float fScore, CogRectangleAffine cogROI, ENDIRECTION enSearchDir, out PointF ptLineStart, out PointF ptLineEnd)
        {
            ptLineStart = new PointF();
            ptLineEnd = new PointF();
            try
            {
                // LINE 검색 영역 설정
                SetInfo(cogROI, enSearchDir);
                if (FindLineProcess(Image, fScore, out ptLineStart, out ptLineEnd) == true)
                    return true;
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.ABNORMAL, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
            return false;
        }
    }
}
