﻿using System;
using System.Diagnostics;
using System.Windows.Forms;
using System.Reflection;

using Cognex.VisionPro;
using Cognex.VisionPro.PMAlign;
using Cognex.VisionPro.Exceptions;
using Cognex.VisionPro.Caliper;
using Cognex.VisionPro.ToolGroup;


namespace IntelligentFactory
{
    public class CCogTool_PMAlign
    {
        public string NAME { get; set; } = "";

        private CogPMAlignTool m_cogPMAlignTool = new CogPMAlignTool();
        public CogPMAlignTool Tool
        {
            get => m_cogPMAlignTool;
            set => m_cogPMAlignTool = value;
        }

        private CogPMAlignResult m_ResultPMAlign = new CogPMAlignResult();
        public CogPMAlignResult Result
        {
            get => m_ResultPMAlign;
            set => m_ResultPMAlign = value;
        }
        private double m_dblX = 0.0;
        private double m_dblY = 0.0;
        private double m_dblAngle = 0.0;
        private double m_dblScore = 0.0;

        public ICogImage TrainedPatternImage
        {
            get
            {
                if (m_cogPMAlignTool == null) return null;
                if (m_cogPMAlignTool.Pattern == null) return null;

                try
                {
                    return m_cogPMAlignTool.Pattern.GetTrainedPatternImage();
                }
                catch (Exception ex)
                {
                    CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
                }

                return null;
            }
        }

        public CCogTool_PMAlign(string strName)
        {
            NAME = strName;
        }

        private string m_strPath = string.Empty;

        public bool LoadConfig(string strRecipe)
        {
            try
            {
                string strPath = $"{Application.StartupPath}\\RECIPE\\{strRecipe}\\{NAME}.vpp";
                if (CogSerializer.LoadObjectFromFile(strPath) is CogPMAlignTool)
                {
                    m_strPath = strPath;
                    m_cogPMAlignTool = CogSerializer.LoadObjectFromFile(strPath) as CogPMAlignTool;
                }
                else
                    return false;
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
            return true;
        }

        public bool LoadConfig_Manual(string strPath)
        {
            try
            {
                if (CogSerializer.LoadObjectFromFile(strPath) is CogPMAlignTool)
                {
                    m_strPath = strPath;
                    m_cogPMAlignTool = CogSerializer.LoadObjectFromFile(strPath) as CogPMAlignTool;
                }
                else
                    return false;
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
            return true;
        }

        public void SaveConfig(string strRecipe)
        {
            try
            {
                string strPath = $"{Application.StartupPath}\\RECIPE\\{strRecipe}\\{NAME}.vpp";
                CogSerializer.SaveObjectToFile(m_cogPMAlignTool, strPath);
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
        }

        public void GetResult(out double dblX, out double dblY, out double dblAngle, out double dblScore)
        {
            dblX = m_dblX;
            dblY = m_dblY;
            dblAngle = m_dblAngle;
            dblScore = m_dblScore;
        }
        /* Pattern 설정
         * Image : source 이미지
         * cogROI : source 이미지에서 Pattern 영역
         * outImage : Train 된 Pattern 이미지
         */
        public bool Train(CogImage8Grey Image, CogRectangleAffine cogROI, out ICogImage outImage)
        {
            outImage = null;
            try
            {
                m_cogPMAlignTool.Pattern.TrainImage = Image;

                // ROI
                m_cogPMAlignTool.Pattern.TrainRegion = cogROI;
                m_cogPMAlignTool.Pattern.Origin.TranslationX = (m_cogPMAlignTool.Pattern.TrainRegion as CogRectangleAffine).CenterX;
                m_cogPMAlignTool.Pattern.Origin.TranslationY = (m_cogPMAlignTool.Pattern.TrainRegion as CogRectangleAffine).CenterY;

                m_cogPMAlignTool.Pattern.Train();

                outImage = m_cogPMAlignTool.Pattern.GetTrainedPatternImage();

                return true;
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
            return false;
        }

        public bool Train(CogImage8Grey Image, out ICogImage outImage)
        {
            outImage = null;
            try
            {
                m_cogPMAlignTool.Pattern.TrainImage = Image;

                // ROI
                m_cogPMAlignTool.Pattern.Origin.TranslationX = (m_cogPMAlignTool.Pattern.TrainRegion as CogRectangleAffine).CenterX;
                m_cogPMAlignTool.Pattern.Origin.TranslationY = (m_cogPMAlignTool.Pattern.TrainRegion as CogRectangleAffine).CenterY;

                m_cogPMAlignTool.Pattern.Train();

                outImage = m_cogPMAlignTool.Pattern.GetTrainedPatternImage();

                return true;
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
            return false;
        }

        public bool Train()
        {
            try
            {
                //트레인 영역의 센터를 패턴 찾은 결과로 받기 위해 Translation X/Y 를 영역의 센터로 지정해준다.
                m_cogPMAlignTool.Pattern.Origin.TranslationX = (m_cogPMAlignTool.Pattern.TrainRegion as CogRectangleAffine).CenterX;
                m_cogPMAlignTool.Pattern.Origin.TranslationY = (m_cogPMAlignTool.Pattern.TrainRegion as CogRectangleAffine).CenterY;

                m_cogPMAlignTool.Pattern.Train();

                return true;
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
            return false;
        }
        /* Pattern 찾기
         * Image : source 이미지
         * dblX : x방향 Pixel 위치
         * dblY : y방향 Pixel 위치
         * dblAngle : 각도 deg
         * dblScore : 정확도
         */
        public bool Run(CogImage8Grey Image, out double dblX, out double dblY, out double dblAngle, out double dblScore)
        {
            dblX = 0.0;
            dblY = 0.0;
            dblAngle = 0.0;
            dblScore = 0.0;

            try
            {
                m_cogPMAlignTool.InputImage = Image;

                //m_cogPMAlignTool.RunParams.ApproximateNumberToFind = 1;
                //m_cogPMAlignTool.RunParams.ZoneAngle.Configuration = CogPMAlignZoneConstants.LowHigh;
                //m_cogPMAlignTool.RunParams.ZoneAngle.Low = -PI;
                //m_cogPMAlignTool.RunParams.ZoneAngle.High = PI;

                m_cogPMAlignTool.Run();

                if (m_cogPMAlignTool.Results == null)
                    return false;
                if (m_cogPMAlignTool.Results.Count > 0)
                {
                    CogPMAlignTool CurrentTool = (CogPMAlignTool)m_cogPMAlignTool;
                    if (CurrentTool.RunStatus.Result == CogToolResultConstants.Error)
                    {
                        Debug.WriteLine(CurrentTool.RunStatus.Message);
                        return false;
                    }
                    else
                    {
                        m_ResultPMAlign = CurrentTool.Results[0];
                        dblX = m_ResultPMAlign.GetPose().TranslationX;
                        dblY = m_ResultPMAlign.GetPose().TranslationY;
                        dblAngle = Common.rad2deg(m_ResultPMAlign.GetPose().Rotation);
                        dblScore = m_ResultPMAlign.Score;
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
            return false;
        }

        public bool Run(CogImage8Grey Image)
        {
            try
            {
                m_cogPMAlignTool.InputImage = Image;

                //m_cogPMAlignTool.RunParams.ApproximateNumberToFind = 1;
                //m_cogPMAlignTool.RunParams.ZoneAngle.Configuration = CogPMAlignZoneConstants.LowHigh;
                //m_cogPMAlignTool.RunParams.ZoneAngle.Low = -PI;
                //m_cogPMAlignTool.RunParams.ZoneAngle.High = PI;

                m_cogPMAlignTool.Run();

                if (m_cogPMAlignTool.Results == null)
                    return false;
                if (m_cogPMAlignTool.Results.Count > 0)
                {
                    CogPMAlignTool CurrentTool = (CogPMAlignTool)m_cogPMAlignTool;
                    if (CurrentTool.RunStatus.Result == CogToolResultConstants.Error)
                    {
                        Debug.WriteLine(CurrentTool.RunStatus.Message);
                        return false;
                    }
                    else
                    {
                        m_ResultPMAlign = CurrentTool.Results[0];
                        m_dblX = m_ResultPMAlign.GetPose().TranslationX;
                        m_dblY = m_ResultPMAlign.GetPose().TranslationY;
                        m_dblAngle = Common.rad2deg(m_ResultPMAlign.GetPose().Rotation);
                        m_dblScore = m_ResultPMAlign.Score;
                    }
                }
                else
                {
                    m_ResultPMAlign = null;
                }

                return true;
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
            return false;
        }
    }
}
